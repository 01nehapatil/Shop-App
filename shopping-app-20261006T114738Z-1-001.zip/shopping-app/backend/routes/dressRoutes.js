const express = require('express');
const router = express.Router();
const { getDressListing, getDressById } = require('../controllers/dressController');

// GET /api/dress_listing        → all dresses (with optional query filters)
// GET /api/dress_listing/:id    → single dress
router.get('/', getDressListing);
router.get('/:id', getDressById);

module.exports = router;
