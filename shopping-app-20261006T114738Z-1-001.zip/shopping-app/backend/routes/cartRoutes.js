const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/authMiddleware');
const { getCart, addToCart, updateCartItem, removeFromCart, clearCart } = require('../controllers/cartController');

router.get('/',                protect, getCart);
router.post('/add',            protect, addToCart);
router.put('/update',          protect, updateCartItem);
router.delete('/remove/:dressId', protect, removeFromCart);
router.delete('/clear',        protect, clearCart);

module.exports = router;
