const express = require('express');
const router = express.Router();
const {
  createPaymentIntent,
  createGooglePayIntent,
  initiatePhonePePayment,
  phonePeCallback,
  listPayments,
} = require('../controllers/paymentController');
const { protect } = require('../middleware/authMiddleware');

// POST /api/payment/create-intent        — Stripe card PaymentIntent
router.post('/create-intent', protect, createPaymentIntent);

// POST /api/payment/create-google-pay-intent — Stripe Google Pay PaymentIntent
router.post('/create-google-pay-intent', protect, createGooglePayIntent);

// POST /api/payment/phonepe-initiate     — PhonePe PG payment page URL
router.post('/phonepe-initiate', protect, initiatePhonePePayment);

// POST /api/payment/phonepe-callback     — PhonePe server-to-server callback (no auth)
router.post('/phonepe-callback', phonePeCallback);

// GET /api/payment/list                  — Admin dashboard: list recent Stripe PaymentIntents
router.get('/list', listPayments);

module.exports = router;
