const mongoose = require('mongoose');

const cartItemSchema = new mongoose.Schema(
  {
    dress:    { type: mongoose.Schema.Types.ObjectId, ref: 'Dress', required: true },
    name:     { type: String, required: true },
    price:    { type: Number, required: true },
    imageUrl: { type: String, default: '' },
    qty:      { type: Number, default: 1, min: 1 },
  },
  { _id: false }
);

const cartSchema = new mongoose.Schema(
  {
    user:  { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
    items: [cartItemSchema],
  },
  { timestamps: true }
);

module.exports = mongoose.model('Cart', cartSchema);
