const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const helmet = require('helmet');
const { sanitize: sanitizeMongo } = require('express-mongo-sanitize');
require('dotenv').config();
const connectDB = require('./config/db');
const productRoutes = require('./routes/productRoutes');
const authRoutes = require('./routes/authRoutes');
const dressRoutes = require('./routes/dressRoutes');
const cartRoutes = require('./routes/cartRoutes');
const paymentRoutes = require('./routes/paymentRoutes');
const { errorHandler } = require('./middleware/errorMiddleware');
const { globalLimiter } = require('./middleware/rateLimiter');

// Enforce required env vars at startup
if (!process.env.JWT_SECRET) {
  console.error('FATAL: JWT_SECRET is not set in environment variables.');
  process.exit(1);
}

// Connect to MongoDB
connectDB();

const app = express();
const PORT = process.env.PORT || 5000;

// ── Security headers (OWASP A05) ──
app.use(helmet());

// ── CORS — restrict to known origins ──
const allowedOrigins = [
  'http://localhost:3000',
  'http://localhost:5173',
  'http://127.0.0.1:3000',
  'http://127.0.0.1:5173',
  'http://localhost:5174',
  'http://127.0.0.1:5174',
];
app.use(cors({
  origin: (origin, cb) => {
    // Allow mobile apps (no origin) and known web origins
    if (!origin || allowedOrigins.includes(origin)) return cb(null, true);
    cb(new Error('Not allowed by CORS'));
  },
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

// ── Body parsing with size limit (OWASP A04) ──
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: false, limit: '10kb' }));

// ── NoSQL injection prevention (OWASP A03) ──
// Express 5 makes req.query read-only, so we sanitize body/params only
app.use((req, _res, next) => {
  if (req.body)   req.body   = sanitizeMongo(req.body);
  if (req.params) req.params = sanitizeMongo(req.params);
  next();
});

// ── Global rate limiter (OWASP A07) ──
app.use(globalLimiter);

// --- Request logger ---
morgan.token('body', (req) => {
  const b = { ...req.body };
  if (b.password) b.password = '***'; // hide passwords
  return Object.keys(b).length ? JSON.stringify(b) : '';
});
app.use(morgan('  :method :url :status :response-time ms — body: :body'));

// --- Routes ---
app.get('/', (req, res) => {
  res.json({ message: 'Shopping API is running' });
});

app.use('/api/products', productRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/dress_listing', dressRoutes);
app.use('/api/cart', cartRoutes);
app.use('/api/payment', paymentRoutes);

// --- Error handler (must be last) ---
app.use(errorHandler);

app.listen(PORT, '127.0.0.1', () => {
  console.log(`Server running on http://127.0.0.1:${PORT}`);
});
