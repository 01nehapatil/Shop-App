const Stripe = require('stripe');
const axios = require('axios');
const crypto = require('crypto');

// Initialise Stripe lazily so the server still boots even if the key is a placeholder
const getStripe = () => {
  if (!process.env.STRIPE_SECRET_KEY || process.env.STRIPE_SECRET_KEY === 'sk_test_YOUR_SECRET_KEY_HERE') {
    throw new Error('STRIPE_SECRET_KEY is not configured. Add your key to .env');
  }
  return Stripe(process.env.STRIPE_SECRET_KEY);
};

/**
 * POST /api/payment/create-intent
 * Body: { amount: number (in dollars), currency?: string, description?: string }
 * Returns: { clientSecret, paymentIntentId }
 */
const createPaymentIntent = async (req, res) => {
  try {
    const stripe = getStripe();
    const { amount, currency = 'usd', description = 'Shopping App Order' } = req.body;

    if (!amount || typeof amount !== 'number' || amount <= 0) {
      return res.status(400).json({ message: 'Valid amount (in dollars) is required' });
    }

    const amountInCents = Math.round(amount * 100);

    const paymentIntent = await stripe.paymentIntents.create({
      amount: amountInCents,
      currency,
      description,
      automatic_payment_methods: { enabled: true },
    });

    res.json({
      clientSecret: paymentIntent.client_secret,
      paymentIntentId: paymentIntent.id,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

/**
 * POST /api/payment/create-google-pay-intent
 * Body: { amount: number (in dollars), currency?: string, description?: string }
 * Returns: { clientSecret, paymentIntentId }
 *
 * Creates a Stripe PaymentIntent configured for Google Pay.
 * The mobile SDK uses this clientSecret to complete the Google Pay flow.
 */
const createGooglePayIntent = async (req, res) => {
  try {
    const stripe = getStripe();
    const { amount, currency = 'usd', description = 'Shopping App Order' } = req.body;

    if (!amount || typeof amount !== 'number' || amount <= 0) {
      return res.status(400).json({ message: 'Valid amount (in dollars) is required' });
    }

    const amountInCents = Math.round(amount * 100);

    const paymentIntent = await stripe.paymentIntents.create({
      amount: amountInCents,
      currency,
      description,
      // Restrict to card-based methods which covers Google Pay
      payment_method_types: ['card'],
    });

    res.json({
      clientSecret: paymentIntent.client_secret,
      paymentIntentId: paymentIntent.id,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

/**
 * POST /api/payment/phonepe-initiate
 * Body: { amount: number (in rupees), description?: string }
 * Returns: { paymentUrl, transactionId }
 *
 * Flow:
 * 1. Mobile sends total amount in INR
 * 2. Backend builds a PhonePe PG payload and requests a payment page URL
 * 3. Mobile opens the returned URL via Linking or WebView
 * 4. User completes payment on PhonePe
 * 5. PhonePe redirects / calls the callbackUrl with status
 *
 * Set PHONEPE_MERCHANT_ID, PHONEPE_SALT_KEY, PHONEPE_SALT_INDEX in .env
 * Leave unset to use PhonePe sandbox test credentials (UAT).
 */
const initiatePhonePePayment = async (req, res) => {
  try {
    const { amount, description = 'Shopping App Order' } = req.body;

    if (!amount || typeof amount !== 'number' || amount <= 0) {
      return res.status(400).json({ message: 'Valid amount (in rupees) is required' });
    }

    const merchantId   = process.env.PHONEPE_MERCHANT_ID  || 'PGTESTPAYUAT86';
    const saltKey      = process.env.PHONEPE_SALT_KEY      || '96434309-7796-489d-8924-ab56988a6076';
    const saltIndex    = process.env.PHONEPE_SALT_INDEX    || '1';
    const isProduction = process.env.PHONEPE_ENV === 'production';

    const merchantTransactionId = `MT${Date.now()}${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
    const merchantUserId = req.user._id.toString();

    const backendUrl  = process.env.BACKEND_URL  || 'http://localhost:5001';
    const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:3000';

    const payload = {
      merchantId,
      merchantTransactionId,
      merchantUserId,
      amount: Math.round(amount * 100), // paise
      redirectUrl: `${frontendUrl}/payment/phonepe-result`,
      redirectMode: 'REDIRECT',
      callbackUrl: `${backendUrl}/api/payment/phonepe-callback`,
      mobileNumber: '',
      paymentInstrument: { type: 'PAY_PAGE' },
    };

    const base64Payload = Buffer.from(JSON.stringify(payload)).toString('base64');
    const hashInput     = base64Payload + '/pg/v1/pay' + saltKey;
    const checksum      = crypto.createHash('sha256').update(hashInput).digest('hex') + '###' + saltIndex;

    const phonePeApiUrl = isProduction
      ? 'https://api.phonepe.com/apis/hermes/pg/v1/pay'
      : 'https://api-preprod.phonepe.com/apis/pg-sandbox/pg/v1/pay';

    const response = await axios.post(
      phonePeApiUrl,
      { request: base64Payload },
      { headers: { 'Content-Type': 'application/json', 'X-VERIFY': checksum, 'X-MERCHANT-ID': merchantId } },
    );

    const paymentUrl = response.data?.data?.instrumentResponse?.redirectInfo?.url;
    if (!paymentUrl) {
      return res.status(502).json({ message: 'PhonePe did not return a payment URL' });
    }

    res.json({ paymentUrl, transactionId: merchantTransactionId });
  } catch (error) {
    const msg = error?.response?.data?.message || error.message;
    res.status(500).json({ message: msg });
  }
};

/**
 * POST /api/payment/phonepe-callback
 * Called by PhonePe servers after payment completion.
 * Verifies the checksum and returns 200 OK.
 */
const phonePeCallback = async (req, res) => {
  try {
    const { response: encodedResponse } = req.body;
    if (!encodedResponse) {
      return res.status(400).json({ message: 'Missing response payload' });
    }

    const saltKey   = process.env.PHONEPE_SALT_KEY   || '96434309-7796-489d-8924-ab56988a6076';
    const saltIndex = process.env.PHONEPE_SALT_INDEX || '1';

    const [receivedHash] = (req.headers['x-verify'] || '').split('###');
    const expectedHash = crypto
      .createHash('sha256')
      .update(encodedResponse + saltKey)
      .digest('hex');

    if (receivedHash !== expectedHash) {
      return res.status(400).json({ message: 'Invalid checksum' });
    }

    const decoded = JSON.parse(Buffer.from(encodedResponse, 'base64').toString('utf8'));
    // decoded.code === 'PAYMENT_SUCCESS' means success
    // You can update your Order/Payment model here based on decoded.data.merchantTransactionId

    res.json({ success: true, code: decoded.code });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

/**
 * GET /api/payment/list
 * Query params: limit (default 50, max 100), last4 (optional filter)
 * Returns the most recent Stripe PaymentIntents with card details.
 * No auth required — this is an admin-only dashboard endpoint served on localhost.
 */
const listPayments = async (req, res) => {
  try {
    const stripe = getStripe();
    const limit = Math.min(parseInt(req.query.limit, 10) || 50, 100);

    // Expand charges so we can read card details (brand / last4)
    const paymentIntents = await stripe.paymentIntents.list({
      limit,
      expand: ['data.latest_charge'],
    });

    const payments = paymentIntents.data.map((pi) => {
      const charge = pi.latest_charge;
      const card = charge?.payment_method_details?.card || null;
      return {
        id: pi.id,
        amount: pi.amount,          // in cents
        currency: pi.currency.toUpperCase(),
        status: pi.status,
        description: pi.description || '—',
        created: pi.created,        // Unix timestamp
        brand: card?.brand || null,
        last4: card?.last4 || null,
        receiptEmail: charge?.receipt_email || null,
      };
    });

    res.json({ payments, hasMore: paymentIntents.has_more });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = { createPaymentIntent, createGooglePayIntent, initiatePhonePePayment, phonePeCallback, listPayments };
