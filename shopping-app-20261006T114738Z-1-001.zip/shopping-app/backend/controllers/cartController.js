const Cart = require('../models/Cart');

// GET /api/cart
const getCart = async (req, res) => {
  try {
    const cart = await Cart.findOne({ user: req.user._id });
    res.json(cart ? cart.items : []);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// POST /api/cart/add  — body: { dressId, name, price, imageUrl, qty? }
const addToCart = async (req, res) => {
  try {
    const { dressId, name, price, imageUrl = '', qty = 1 } = req.body;
    if (!dressId || !name || price === undefined) {
      return res.status(400).json({ message: 'dressId, name and price are required' });
    }

    let cart = await Cart.findOne({ user: req.user._id });
    if (!cart) {
      cart = new Cart({ user: req.user._id, items: [] });
    }

    const idx = cart.items.findIndex(i => i.dress.toString() === dressId);
    if (idx > -1) {
      cart.items[idx].qty += qty;
    } else {
      cart.items.push({ dress: dressId, name, price, imageUrl, qty });
    }

    await cart.save();
    res.json(cart.items);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// PUT /api/cart/update  — body: { dressId, qty }
const updateCartItem = async (req, res) => {
  try {
    const { dressId, qty } = req.body;
    if (!dressId || qty === undefined) {
      return res.status(400).json({ message: 'dressId and qty are required' });
    }

    const cart = await Cart.findOne({ user: req.user._id });
    if (!cart) return res.status(404).json({ message: 'Cart not found' });

    const idx = cart.items.findIndex(i => i.dress.toString() === dressId);
    if (idx === -1) return res.status(404).json({ message: 'Item not in cart' });

    if (qty <= 0) {
      cart.items.splice(idx, 1);
    } else {
      cart.items[idx].qty = qty;
    }

    await cart.save();
    res.json(cart.items);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// DELETE /api/cart/remove/:dressId
const removeFromCart = async (req, res) => {
  try {
    const { dressId } = req.params;
    const cart = await Cart.findOne({ user: req.user._id });
    if (!cart) return res.status(404).json({ message: 'Cart not found' });

    cart.items = cart.items.filter(i => i.dress.toString() !== dressId);
    await cart.save();
    res.json(cart.items);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// DELETE /api/cart/clear
const clearCart = async (req, res) => {
  try {
    const cart = await Cart.findOne({ user: req.user._id });
    if (cart) {
      cart.items = [];
      await cart.save();
    }
    res.json([]);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

module.exports = { getCart, addToCart, updateCartItem, removeFromCart, clearCart };
