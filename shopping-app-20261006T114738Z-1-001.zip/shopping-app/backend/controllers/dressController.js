const Dress = require('../models/Dress');

// @desc  Get all dresses
// @route GET /api/dress_listing
const getDressListing = async (req, res) => {
  try {
    const { category, minPrice, maxPrice, color, sort } = req.query;

    const filter = {};
    if (category) filter.category = { $regex: category, $options: 'i' };
    if (color) filter.color = { $regex: color, $options: 'i' };
    if (minPrice || maxPrice) {
      filter.price = {};
      if (minPrice) filter.price.$gte = Number(minPrice);
      if (maxPrice) filter.price.$lte = Number(maxPrice);
    }

    let query = Dress.find(filter);

    if (sort === 'price_asc') query = query.sort({ price: 1 });
    else if (sort === 'price_desc') query = query.sort({ price: -1 });
    else if (sort === 'rating') query = query.sort({ rating: -1 });
    else query = query.sort({ createdAt: -1 });

    const dresses = await query;
    res.json(dresses);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc  Get single dress
// @route GET /api/dress_listing/:id
const getDressById = async (req, res) => {
  try {
    const dress = await Dress.findById(req.params.id);
    if (!dress) return res.status(404).json({ message: 'Dress not found' });
    res.json(dress);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = { getDressListing, getDressById };
