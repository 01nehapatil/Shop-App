/**
 * @format
 */

import {AppRegistry, Text, TextInput} from 'react-native';
import App from './App';
import {name as appName} from './app.json';

// Apply Lexend font globally to every Text and TextInput in the app
const defaultTextStyle = Text.defaultProps?.style ?? {};
Text.defaultProps = {
  ...(Text.defaultProps || {}),
  style: [defaultTextStyle, {fontFamily: 'Lexend-Regular'}],
};

const defaultInputStyle = TextInput.defaultProps?.style ?? {};
TextInput.defaultProps = {
  ...(TextInput.defaultProps || {}),
  style: [defaultInputStyle, {fontFamily: 'Lexend-Regular'}],
};

AppRegistry.registerComponent(appName, () => App);
