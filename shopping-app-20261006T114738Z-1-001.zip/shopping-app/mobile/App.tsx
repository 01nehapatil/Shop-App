import React from 'react';
import {StyleSheet, StatusBar, Text, ActivityIndicator, View} from 'react-native';
import {NavigationContainer} from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import LinearGradient from 'react-native-linear-gradient';
import {SafeAreaProvider} from 'react-native-safe-area-context';
import {AuthProvider, useAuth} from './src/context/AuthContext';
import {CartProvider, useCart} from './src/context/CartContext';
import {ThemeProvider} from './src/context/ThemeContext';
import {useTheme} from './src/hooks/useTheme';
import {StripeProvider} from '@stripe/stripe-react-native';
import {STRIPE_PUBLISHABLE_KEY} from './src/api/api';
import CustomTabBar from './src/tab/CustomTabBar';
import LoginScreen from './src/screens/LoginScreen';
import RegisterScreen from './src/screens/RegisterScreen';
import DressListingScreen from './src/screens/DressListingScreen';
import HomeScreen from './src/screens/HomeScreen';
import CartScreen from './src/screens/CartScreen';
import ProfileScreen from './src/screens/ProfileScreen';
import CheckoutScreen from './src/screens/CheckoutScreen';
import HistoryScreen from './src/screens/HistoryScreen';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

const TAB_ICONS: Record<string, string> = {
  Dresses: '👗',
  Shop: '🛍️',
  Cart: '🛒',
  Profile: '👤',
  // Transactions: '💳',
};

function TabIcon({name, focused}: {name: string; focused: boolean}) {
  return (
    <Text style={focused ? styles.tabIconActive : styles.tabIconInactive}>
      {TAB_ICONS[name]}
    </Text>
  );
}

function GradientHeader() {
  const {colors} = useTheme();
  return (
    <LinearGradient
      colors={[colors.primaryDeep, colors.primary, colors.primaryTeal]}
      start={{x: 0, y: 0}}
      end={{x: 1, y: 0}}
      style={StyleSheet.absoluteFill}
    />
  );
}
function MainTabs() {
  const {totalItems} = useCart();
  const {colors} = useTheme();

  return (
    <Tab.Navigator
      tabBar={props => <CustomTabBar {...props} />}
      screenOptions={{
        headerBackground: () => <GradientHeader />,
        headerTintColor: colors.bgWhite,
        headerTitleStyle: {
          fontFamily: 'Lexend-ExtraBold',
          fontSize: 18,
          color: colors.bgWhite,
        },
      }}>
      <Tab.Screen
        name="Dresses"
        component={DressListingScreen}
        options={{title: 'Dresses'}}
      />

      <Tab.Screen
        name="Shop"
        component={HomeScreen}
        options={{title: 'Shop'}}
      />

      <Tab.Screen
        name="Cart"
        component={CartScreen}
        options={{
          title: 'Cart',
          tabBarBadge: totalItems > 0 ? totalItems : undefined,
        }}
      />

      <Tab.Screen
        name="Transactions"
        component={HistoryScreen}
        options={{title: 'Transactions'}}
      />

      <Tab.Screen
        name="Profile"
        component={ProfileScreen}
        options={{title: 'Profile'}}
      />
    </Tab.Navigator>
  );
}

function RootNavigator() {
  const {user, loading} = useAuth();
  const {colors, isDark} = useTheme();
  if (loading) {
    return (
      <View style={{flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: colors.bgScreen}}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }
  return (
    <>
      <StatusBar
        barStyle={isDark ? 'light-content' : 'light-content'}
        backgroundColor={colors.primaryDeep}
      />
      <Stack.Navigator screenOptions={{headerShown: false}}>
        {user ? (
          <>
            <Stack.Screen name="Main" component={MainTabs} />
            <Stack.Screen name="Checkout" component={CheckoutScreen} />
          </>
        ) : (
          <>
            <Stack.Screen name="Login" component={LoginScreen} />
            <Stack.Screen name="Register" component={RegisterScreen} />
          </>
        )}
      </Stack.Navigator>
    </>
  );
}

export default function App() {
  return (
    <StripeProvider publishableKey={STRIPE_PUBLISHABLE_KEY}>
      <ThemeProvider>
        <AuthProvider>
          <CartProvider>
            <SafeAreaProvider>
              <NavigationContainer>
                <RootNavigator />
              </NavigationContainer>
            </SafeAreaProvider>
          </CartProvider>
        </AuthProvider>
      </ThemeProvider>
    </StripeProvider>
  );
}

const styles = StyleSheet.create({
  tabIconActive: {fontSize: 20, opacity: 1},
  tabIconInactive: {fontSize: 20, opacity: 0.45},
});
