import React, { useState, useEffect } from "react";

const API_BASE = "http://127.0.0.1:5001";

const formatAmount = (amountCents, currency) => {
  const value = amountCents / 100;
  try {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: currency || "USD",
    }).format(value);
  } catch {
    return `${currency} ${value.toFixed(2)}`;
  }
};

const formatDate = (unix) => {
  const d = new Date(unix * 1000);
  return d.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" }) +
    " " + d.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
};

const STATUS_COLORS = {
  succeeded: { bg: "#dcfce7", color: "#166534" },
  requires_payment_method: { bg: "#fef9c3", color: "#854d0e" },
  requires_confirmation: { bg: "#fef9c3", color: "#854d0e" },
  requires_action: { bg: "#fff7ed", color: "#9a3412" },
  processing: { bg: "#dbeafe", color: "#1e40af" },
  canceled: { bg: "#fee2e2", color: "#991b1b" },
};

const Dashboard = ({ email, onLogout }) => {
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filter, setFilter] = useState("");

  const fetchPayments = () => {
    setLoading(true);
    setError(null);
    fetch(`${API_BASE}/api/payment/list?limit=50`)
      .then((res) => {
        if (!res.ok) return res.json().then((d) => Promise.reject(d.message || "Server error"));
        return res.json();
      })
      .then((data) => {
        setPayments(data.payments || []);
        setLoading(false);
      })
      .catch((err) => {
        setError(typeof err === "string" ? err : "Failed to load payments");
        setLoading(false);
      });
  };

  useEffect(() => { fetchPayments(); }, []);

  const filtered = payments.filter((p) => {
    if (!filter) return true;
    const q = filter.toLowerCase();
    return (
      p.id.toLowerCase().includes(q) ||
      (p.last4 && p.last4.includes(q)) ||
      (p.brand && p.brand.toLowerCase().includes(q)) ||
      p.status.toLowerCase().includes(q) ||
      (p.receiptEmail && p.receiptEmail.toLowerCase().includes(q))
    );
  });

  const totalSucceeded = payments
    .filter((p) => p.status === "succeeded")
    .reduce((sum, p) => sum + p.amount, 0);

  const succeededCount = payments.filter((p) => p.status === "succeeded").length;
  const pendingCount = payments.filter((p) => p.status !== "succeeded" && p.status !== "canceled").length;

  return (
    <div style={styles.layout}>
      {/* Sidebar */}
      <aside style={styles.sidebar}>
        <div style={styles.sidebarLogo}>
          <span style={styles.logoIcon}>💳</span>
          <span style={styles.logoText}>PayFlow</span>
        </div>
        <nav style={styles.nav}>
          {[
            { icon: "🏠", label: "Dashboard", active: true },
            { icon: "💰", label: "Payments" },
            { icon: "📊", label: "Analytics" },
            { icon: "⚙️", label: "Settings" },
          ].map(({ icon, label, active }) => (
            <div key={label} style={{ ...styles.navItem, ...(active ? styles.navItemActive : {}) }}>
              <span>{icon}</span>
              <span>{label}</span>
            </div>
          ))}
        </nav>
        <div style={styles.sidebarFooter}>
          <div style={styles.userBadge}>
            <div style={styles.avatar}>{email ? email[0].toUpperCase() : "A"}</div>
            <div style={styles.userInfo}>
              <div style={styles.userName}>Admin</div>
              <div style={styles.userEmail}>{email}</div>
            </div>
          </div>
          <button style={styles.logoutBtn} onClick={onLogout}>Logout</button>
        </div>
      </aside>

      {/* Main */}
      <main style={styles.main}>
        {/* Top bar */}
        <div style={styles.topBar}>
          <div>
            <h1 style={styles.pageTitle}>Stripe Payments Dashboard</h1>
            <p style={styles.pageSubtitle}>Live payment data from your Stripe account</p>
          </div>
          <button style={styles.refreshBtn} onClick={fetchPayments} disabled={loading}>
            {loading ? "⏳ Loading…" : "🔄 Refresh"}
          </button>
        </div>

        {/* Stats row */}
        <div style={styles.statsRow}>
          <div style={styles.statCard}>
            <div style={styles.statIcon}>💰</div>
            <div>
              <div style={styles.statLabel}>Total Collected</div>
              <div style={styles.statValue}>{formatAmount(totalSucceeded, "USD")}</div>
            </div>
          </div>
          <div style={styles.statCard}>
            <div style={styles.statIcon}>✅</div>
            <div>
              <div style={styles.statLabel}>Succeeded</div>
              <div style={{ ...styles.statValue, color: "#166534" }}>{succeededCount}</div>
            </div>
          </div>
          <div style={styles.statCard}>
            <div style={styles.statIcon}>⏳</div>
            <div>
              <div style={styles.statLabel}>Pending / Other</div>
              <div style={{ ...styles.statValue, color: "#854d0e" }}>{pendingCount}</div>
            </div>
          </div>
          <div style={styles.statCard}>
            <div style={styles.statIcon}>📋</div>
            <div>
              <div style={styles.statLabel}>Total Transactions</div>
              <div style={styles.statValue}>{payments.length}</div>
            </div>
          </div>
        </div>

        {/* Search bar */}
        <div style={styles.searchBar}>
          <span style={styles.searchIcon}>🔍</span>
          <input
            style={styles.searchInput}
            placeholder="Search by Payment ID, card last4, status, email…"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          />
          {filter && (
            <button style={styles.clearBtn} onClick={() => setFilter("")}>✕</button>
          )}
        </div>

        {/* Payment Table */}
        <div style={styles.tableCard}>
          <div style={styles.tableHeader}>
            <h2 style={styles.tableTitle}>
              Stripe Payment Intents
              <span style={styles.tableBadge}>
                {filtered.length} of {payments.length}
              </span>
            </h2>
          </div>

          {error && (
            <div style={styles.errorBox}>
              <strong>⚠️ Error:</strong> {error}
              <br />
              <small>Make sure the backend is running on port 5000 and STRIPE_SECRET_KEY is set.</small>
            </div>
          )}

          {loading ? (
            <div style={styles.loadingBox}>⏳ Fetching payments from Stripe…</div>
          ) : (
            <div style={styles.tableWrapper}>
              <table style={styles.table}>
                <thead>
                  <tr style={styles.tableHeadRow}>
                    <th style={styles.th}>#</th>
                    <th style={styles.th}>Payment ID</th>
                    <th style={styles.th}>Amount</th>
                    <th style={styles.th}>Currency</th>
                    <th style={{ ...styles.th, textAlign: "center" }}>Card</th>
                    <th style={{ ...styles.th, textAlign: "center" }}>Status</th>
                    <th style={styles.th}>Description</th>
                    <th style={styles.th}>Receipt Email</th>
                    <th style={styles.th}>Date</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.length === 0 ? (
                    <tr>
                      <td colSpan={9} style={styles.emptyCell}>
                        {payments.length === 0 ? "No payments found in Stripe." : "No results match your search."}
                      </td>
                    </tr>
                  ) : (
                    filtered.map((p, i) => {
                      const statusStyle = STATUS_COLORS[p.status] || { bg: "#f3f4f6", color: "#374151" };
                      const isTestCard4444 = p.last4 === "4444";
                      return (
                        <tr
                          key={p.id}
                          style={{
                            ...styles.tableRow,
                            background: i % 2 === 0 ? "#fff" : "#f9fafb",
                            ...(isTestCard4444 ? styles.highlightRow : {}),
                          }}
                        >
                          <td style={styles.td}>{i + 1}</td>
                          <td style={{ ...styles.td, fontFamily: "monospace", fontSize: "12px", color: "#6366f1" }}>
                            {p.id}
                          </td>
                          <td style={{ ...styles.td, fontWeight: 600 }}>
                            {formatAmount(p.amount, p.currency)}
                          </td>
                          <td style={styles.td}>{p.currency}</td>
                          <td style={{ ...styles.td, textAlign: "center" }}>
                            {p.last4 ? (
                              <span style={styles.cardChip}>
                                {p.brand ? p.brand.charAt(0).toUpperCase() + p.brand.slice(1) : "Card"} ···· {p.last4}
                                {isTestCard4444 && <span style={styles.testBadge}>TEST</span>}
                              </span>
                            ) : (
                              <span style={{ color: "#9ca3af" }}>—</span>
                            )}
                          </td>
                          <td style={{ ...styles.td, textAlign: "center" }}>
                            <span style={{
                              padding: "3px 10px",
                              borderRadius: "9999px",
                              fontSize: "12px",
                              fontWeight: 600,
                              background: statusStyle.bg,
                              color: statusStyle.color,
                            }}>
                              {p.status}
                            </span>
                          </td>
                          <td style={{ ...styles.td, maxWidth: "160px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                            {p.description}
                          </td>
                          <td style={{ ...styles.td, fontSize: "13px", color: "#6b7280" }}>
                            {p.receiptEmail || "—"}
                          </td>
                          <td style={{ ...styles.td, fontSize: "13px", color: "#6b7280", whiteSpace: "nowrap" }}>
                            {formatDate(p.created)}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

const styles = {
  layout: { display: "flex", minHeight: "100vh", background: "#f1f5f9", fontFamily: "system-ui, sans-serif" },
  sidebar: { width: "240px", background: "#1e1b4b", color: "#e0e7ff", display: "flex", flexDirection: "column", padding: "24px 0", flexShrink: 0 },
  sidebarLogo: { display: "flex", alignItems: "center", gap: "10px", padding: "0 24px 24px", borderBottom: "1px solid #312e81" },
  logoIcon: { fontSize: "24px" },
  logoText: { fontSize: "20px", fontWeight: 700, color: "#fff" },
  nav: { flex: 1, padding: "16px 12px", display: "flex", flexDirection: "column", gap: "4px" },
  navItem: { display: "flex", alignItems: "center", gap: "10px", padding: "10px 12px", borderRadius: "8px", cursor: "pointer", color: "#a5b4fc", fontSize: "15px" },
  navItemActive: { background: "#312e81", color: "#fff", fontWeight: 600 },
  sidebarFooter: { padding: "16px 16px 0", borderTop: "1px solid #312e81" },
  userBadge: { display: "flex", alignItems: "center", gap: "10px", marginBottom: "12px" },
  avatar: { width: "36px", height: "36px", borderRadius: "50%", background: "#6366f1", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, color: "#fff" },
  userInfo: { flex: 1, overflow: "hidden" },
  userName: { fontWeight: 600, color: "#fff", fontSize: "13px" },
  userEmail: { fontSize: "11px", color: "#a5b4fc", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" },
  logoutBtn: { width: "100%", padding: "8px", background: "#312e81", color: "#e0e7ff", border: "none", borderRadius: "6px", cursor: "pointer", fontSize: "13px", marginBottom: "8px" },
  main: { flex: 1, padding: "32px", overflowX: "auto" },
  topBar: { display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "28px" },
  pageTitle: { margin: 0, fontSize: "26px", fontWeight: 700, color: "#1e1b4b" },
  pageSubtitle: { margin: "4px 0 0", color: "#6b7280", fontSize: "14px" },
  refreshBtn: { padding: "10px 20px", background: "#6366f1", color: "#fff", border: "none", borderRadius: "8px", cursor: "pointer", fontWeight: 600, fontSize: "14px" },
  statsRow: { display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "16px", marginBottom: "24px" },
  statCard: { background: "#fff", borderRadius: "12px", padding: "20px", display: "flex", alignItems: "center", gap: "16px", boxShadow: "0 1px 3px rgba(0,0,0,0.08)" },
  statIcon: { fontSize: "28px" },
  statLabel: { fontSize: "12px", color: "#6b7280", fontWeight: 500, marginBottom: "4px" },
  statValue: { fontSize: "22px", fontWeight: 700, color: "#1e1b4b" },
  searchBar: { display: "flex", alignItems: "center", background: "#fff", borderRadius: "10px", padding: "0 16px", marginBottom: "20px", boxShadow: "0 1px 3px rgba(0,0,0,0.08)", border: "1px solid #e5e7eb" },
  searchIcon: { fontSize: "16px", marginRight: "8px", color: "#9ca3af" },
  searchInput: { flex: 1, border: "none", outline: "none", padding: "12px 0", fontSize: "14px", background: "transparent" },
  clearBtn: { background: "none", border: "none", cursor: "pointer", color: "#9ca3af", fontSize: "16px" },
  tableCard: { background: "#fff", borderRadius: "14px", boxShadow: "0 1px 3px rgba(0,0,0,0.08)", overflow: "hidden" },
  tableHeader: { padding: "20px 24px", borderBottom: "1px solid #f3f4f6" },
  tableTitle: { margin: 0, fontSize: "17px", fontWeight: 700, color: "#1e1b4b", display: "flex", alignItems: "center", gap: "10px" },
  tableBadge: { background: "#ede9fe", color: "#6d28d9", fontSize: "12px", fontWeight: 600, padding: "2px 8px", borderRadius: "9999px" },
  tableWrapper: { overflowX: "auto" },
  table: { width: "100%", borderCollapse: "collapse" },
  tableHeadRow: { background: "#f8fafc" },
  th: { padding: "12px 16px", textAlign: "left", fontSize: "12px", fontWeight: 600, color: "#6b7280", textTransform: "uppercase", letterSpacing: "0.04em", borderBottom: "1px solid #f1f5f9" },
  tableRow: { borderBottom: "1px solid #f1f5f9", transition: "background 0.15s" },
  td: { padding: "13px 16px", fontSize: "14px", color: "#374151", verticalAlign: "middle" },
  cardChip: { display: "inline-flex", alignItems: "center", gap: "6px", background: "#f0f9ff", color: "#0369a1", padding: "3px 10px", borderRadius: "6px", fontSize: "13px", fontWeight: 600 },
  testBadge: { background: "#fef08a", color: "#854d0e", fontSize: "10px", padding: "1px 5px", borderRadius: "4px", fontWeight: 700 },
  highlightRow: { outline: "2px solid #a5b4fc", outlineOffset: "-1px" },
  errorBox: { margin: "16px 24px", padding: "14px 18px", background: "#fef2f2", border: "1px solid #fecaca", borderRadius: "8px", color: "#991b1b", fontSize: "14px", lineHeight: 1.6 },
  loadingBox: { padding: "40px", textAlign: "center", color: "#6b7280", fontSize: "15px" },
  emptyCell: { padding: "40px", textAlign: "center", color: "#9ca3af", fontSize: "14px" },
};

export default Dashboard;